/*
Emma Werner
COM 210
Lab 3!!!!!!!
:)
 */
package lab3;

import java.util.*;

public class Lab3 
{//start class
    
    int maxSize;
    int[] stackArray;
    int top;

    public static void main(String[] args) 
    {//start main
        Lab3 stack1 = new Lab3(1000000);
        Scanner kb = new Scanner(System.in);
        System.out.println("Enter a phrase with BRACKETS!");
        String s = kb.nextLine();
        int stringLength = s.length();
        
        char p;
        String d;
        for(int i = 0; i < stringLength; i++)
        {//start for
           p = s.charAt(i);
           d = String.valueOf(p);
           if(d.equals("["))
           {//start if
               stack1.push(0);
           }//end if
           if(d.equals("]"))
           {//start if
               stack1.pop(0);
           }//end if
        }//end for
        
        if(stack1.isEmpty() == true)
        {//start if
            System.out.println("The string is balanced.");
        }//end if
        else
        {//start else
            System.out.println("The string is NOT balanced.");
        }//end else
    }//end main
    
    public Lab3(int s)
    {//start constructor
        maxSize = s;
        stackArray = new int[maxSize];
        top = -1; //no items yet
    }//end constructor       
    
    public boolean push(int j) 
    {//start push
      stackArray[++top]=j; 
      return true; 
    }//end push
    
    public int pop(int i)
    {//start pop
        return stackArray[top--];
    }//end pop     
    
    public boolean isEmpty()
    {//start isEmpty
        return(top == -1);
    }//end isEmpty     
    
    public boolean isFull()
    {//start isFull
        return(top == maxSize-1);
    }//end isFull
    
}//end class
