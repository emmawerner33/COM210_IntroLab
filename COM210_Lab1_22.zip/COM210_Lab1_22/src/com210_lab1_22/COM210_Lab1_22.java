/*
 Emma Werner
Lab 1
Number 2
:))))
 */

package com210_lab1_22;

import java.util.Scanner;
import java.util.Arrays; 

public class COM210_Lab1_22 
{//start class

    public static void main(String[] args) 
    {//start main
        Scanner kb = new Scanner(System.in);
        
        System.out.println("Enter first item ");
        String item1 = kb.next();
        
        System.out.println("Enter second item ");
        String item2 = kb.next();
        
        System.out.println("Enter third item ");
        String item3 = kb.next();
        
        String Items[] = {item1, item2, item3};
        
        System.out.println("Enter price of the first item ");
        Double price1 = kb.nextDouble();
        
        System.out.println("Enter the price of the second item ");
        Double price2 = kb.nextDouble();
        
        System.out.println("Enter the price of the third item ");
        Double price3 = kb.nextDouble();
        
        Double Prices[] = {price1, price2, price3};
        
        boolean itemPeas = false;
        for(int i = 0; i < Items.length; i++)
        {//start for
            if(Items[i].toLowerCase().equals("peas"))
            {//start if
               itemPeas = true; 
            }//end if
        }//end for
        
        System.out.println("Items: " + Arrays.toString(Items));
        System.out.println("Prices: " + Arrays.toString(Prices)); 
        
        if(itemPeas)
        {//start if
            Double average = (price1 + price2+ price3)/3;
            String avg = average.toString(); 
            System.out.println("The average price of the items is " + "$"+ avg); 
        }//end if
        else
        {//start else
            System.out.println("No average output.");
        }//end else
    }//end main
    
}//end class

