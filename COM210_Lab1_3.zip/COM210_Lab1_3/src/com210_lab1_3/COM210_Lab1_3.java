/*
 Emma Werner
COM 210
Lab 1
Question 3!!
:)))
 */
package com210_lab1_3;

import java.util.Scanner;
import java.util.Arrays; 

public class COM210_Lab1_3 
{//start class

    public static void main(String[] args) 
    {//start main method
        Scanner kb = new Scanner(System.in);
        System.out.println("Please enter the number of items you'd like to input: ");
        int numItems = kb.nextInt();
        kb.nextLine();
        
        String[] Items = new String[numItems];
        for(int i = 0; i < numItems; i++)
        {//start for
            int itemNum = i + 1;
            System.out.println("Enter item " + itemNum + " name:");
            Items[i] = kb.nextLine(); 
        }//end for
        
        double[] Prices = new double[numItems];
        for(int i = 0; i < numItems; i++)
        {//start for
            int itemNum = i + 1;
            System.out.println("Enter item " + itemNum + " price:");
            Prices[i] = kb.nextDouble(); 
        }//end for
        
        boolean itemPeas = false;
        for(int i = 0; i < Items.length; i++)
        {//start for
            if(Items[i].toLowerCase().equals("peas"))
            {//start if
               itemPeas = true; 
            }//end if
        }//end for
        
        //System.out.println("Items: " + Arrays.toString(Items));
        //System.out.println("Prices: " + Arrays.toString(Prices)); 
        
        System.out.println("Your Items:");
        for(int i = Items.length - 1; i >= 0; i--)
        {//start for
            System.out.println("The " + Items[i] + " costs $" + Prices[i]);
        }//end for
        
        if(itemPeas)
        {//start if
            double average = 0;
            for(int i = 0; i < Prices.length; i++)
            {//start for
                average += Prices[i];
            }//end for
            average /= Prices.length;
            System.out.println("The average price of the items is " + "$"+ average); 
        }//end if
        else
        {//start else
            System.out.println("No average output.");
        }//end else
        
    }//end main method
    
}//end class
