/*
 Emma Werner
Lab 2 Part 2
I needed to do this on a separate one
Don't let the title confuse you it has the sorted and unsorted array insert algos in it
:)
 */
package lab_2sortedinsert;

public class Lab_2SortedInsert 
{//start class

    public static void main(String[] args) 
    {//start main
        //make a sorted small array
        int i;
        int[] SmallArray = new int[11];
        for (i = 0; i < 11; i++)
        {//start for
            SmallArray[i] = i;
        }//end for
        
        //make a sorted medium array
        int j;
        int[] MedArray = new int[101];
        for (j = 0; j < 101; j++)
        {//start for
            MedArray[j] = j;
        }//end for
        
        //make a sorted large array
        int k;
        int[] LargeArray = new int[1001];
        for (k = 0; k < 1001; k++)
        {//start for
            LargeArray[k] = k;
        }//end for
        
        int capacity = SmallArray.length;
        int n = 10;
        int key = 10; 
        
        int capacity2 = MedArray.length;
        int n2 = 100;
        int key2 = 100; 
        
        int capacity3 = LargeArray.length;
        int n3 = 1000;
        int key3 = 1000;
        
        System.out.println("Array 1 Before Insertion: ");
        for(int y = 0; y < n; y++)
            System.out.println(SmallArray[y] + " ");
        
        n = insert(SmallArray, n, key, capacity);
        
        System.out.println("Array 1 After Insertion: ");
        for (int y = 0; y < n; y++)
            System.out.println(SmallArray[y] + " ");
//        
//        System.out.println("Array 2 Before Insertion: ");
//        for(int y2 = 0; y2 < n2; y2++)
//            System.out.println(MedArray[y2] + " ");
//        
//        n2 = Insert(MedArray, n2, key2, capacity2);
//        
//        System.out.println("Array 2 After Insertion: ");
//        for (int y2 = 0; y2 < n2; y2++)
//            System.out.println(MedArray[y2] + " ");
//        
//        System.out.println("Array 3 Before Insertion: ");
//        for(int y3 = 0; y3 < n3; y3++)
//            System.out.println(LargeArray[y3] + " ");
        
//        n3 = Insert(LargeArray, n3, key3, capacity3);
        
//        System.out.println("Array 3 After Insertion: ");
//        for (int y3 = 0; y3 < n3; y3++)
//            System.out.println(LargeArray[y3] + " ");
        
        insertUnsorted(SmallArray);
        insertUnsorted(MedArray);
        insertUnsorted(LargeArray); 
        
    }//end main
    
    public static int insertSorted(int array[], int low, int high, int insertedNum)
    {//start Insert
        int[] newArray = new int[array.length+1];
        return 0; 
    }//end Insert
    
    public static int insert(int MedArray[], int n2, int key2, int capacity2)
    {//start Insert2
        if (n2 >= capacity2)
            return n2;
        int y2;
        for (y2 = n2 - 1; (y2 >= 0 && MedArray[y2] > key2); y2--)
            MedArray[y2 + 1] = MedArray[y2];
        MedArray[y2 + 1] = key2;
        return (n2 + 1);
    }//end Insert2
//    
//    static int Insert3(int LargeArray[], int n3, int key3, int capacity3)
//    {//start Insert3
//        if (n3 >= capacity3)
//            return n3;
//        int y3;
//        for (y3 = n3 - 1; (y3 >= 0 && LargeArray[y3] > key3); y3--)
//            LargeArray[y3 + 1] = LargeArray[y3];
//        LargeArray[y3 + 1] = key3;
//        return (n3 + 1); 
//    }//end Insert3
    
    public static void insertUnsorted(int[] array)
    {//start insertUnsorted
        int next = array.length - 1;
        int num = (int)(1 + Math.random() * (100-1));
        array[next] = num;
        next = next + 1;
    }//start insertUnsorted
    
    
}//end class
