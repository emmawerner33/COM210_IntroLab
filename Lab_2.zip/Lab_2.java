/*
Emma Werner
COM 210
Lab 2!!!
Fetch stuff
:)))
 */
package lab_2;

public class Lab_2 
{//start class

    public static void main(String[] args) 
    {//start main
        //make a sorted small array
        int i;
        int[] SmallArray = new int[10];
        for (i = 0; i < 10; i++)
        {//start for
            SmallArray[i] = i;
        }//end for
        
        //make a sorted medium array
        int j;
        int[] MedArray = new int[100];
        for (j = 0; j < 100; j++)
        {//start for
            MedArray[j] = j;
        }//end for
        
        //make a sorted large array
        int k;
        int[] LargeArray = new int[1000];
        for (k = 0; k < 1000; k++)
        {//start for
            LargeArray[k] = k;
        }//end for
        
        int n, key;
        int counter1 = 0;
        n = SmallArray.length - 1;
        key = SmallArray[SmallArray.length - 1];
        
        int n2, key2;
        n2 = MedArray.length - 1;
        key2 = MedArray[MedArray.length - 1];
        
        int n3, key3;
        n3 = LargeArray.length - 1;
        key3 = LargeArray[LargeArray.length - 1];
        
        System.out.println("Index: " + Fetch(SmallArray, 0, n, key, counter1));
        System.out.println("Index: " + Fetch2(MedArray, 0, n2, key2));
        System.out.println("Index: " + Fetch3(LargeArray, 0, n3, key3));
        
        System.out.println(counter1);
        
        fetchUnsorted(SmallArray);
        fetchUnsorted(MedArray);
        fetchUnsorted(LargeArray); 
        
    }//end main
    
   
    static int Fetch(int SmallArray[], int low, int high, int key, int count)
    {//start Fetch
        System.out.println("hello");
        count++;
        if (high < low)
            return -1;
        int mid = (low + high)/2;
        if (key == SmallArray[mid]){
            System.out.println("Counter for SmallArray: " + count);
            return mid;
        }
        if (key > SmallArray[mid])
            return Fetch(SmallArray, (mid + 1), high, key, count);
        return Fetch(SmallArray, low, (mid - 1), key, count);
    }//end Fetch
    
    static int Fetch2(int MedArray[], int low2, int high2, int key2)
    {//start Fetch2
        System.out.println("poopy");
        if (high2 < low2)
            return -1;
        int mid2 = (low2 + high2)/2;
        if (key2 == MedArray[mid2])
            return mid2;
        if (key2 > MedArray[mid2])
            return Fetch2(MedArray, (mid2 + 1), high2, key2);
        return Fetch2(MedArray, low2, (mid2 - 1), key2);       
    }//end Fetch2
    
    static int Fetch3(int LargeArray[], int low3, int high3, int key3)
    {//start Fetch3
        System.out.println("cheese");
        if (high3 < low3)
            return -1;
        int mid3 = (low3 + high3)/2;
        if (key3 == LargeArray[mid3])
            return mid3;
        if (key3 > LargeArray[mid3])
            return Fetch3(LargeArray, (mid3 + 1), high3, key3);
        return Fetch3(LargeArray, low3, (mid3 - 1), key3);
    }//end Fetch3
    
    public static void fetchUnsorted(int[] array)
    {//start fetchUnsorted
        int count = 0;
        for(int x = 0; x < array.length - 1; x++)
        {//start for 
            if(x == array.length - 1)
            {//start if
              System.out.println(array[x]);  
            }//end if
            count = count + 1; 
        }//end for 
        System.out.println("This array took " + count + " steps!"); 
    }//end fetchUnsorted
    
}//end class
