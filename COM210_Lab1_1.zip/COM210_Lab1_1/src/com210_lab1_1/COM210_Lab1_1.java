/*
Emma Werner
Lab 1 
COM 210 SP23
Program #1
:)))))
 */

package com210_lab1_1;

import java.util.Scanner;
import java.util.Arrays;

public class COM210_Lab1_1 
{//start class

    public static void main(String[] args) 
    {//start main method
        Scanner kb = new Scanner(System.in);
        
        System.out.println("Enter first item ");
        String item1 = kb.next();
        
        System.out.println("Enter second item ");
        String item2 = kb.next();
        
        System.out.println("Enter third item ");
        String item3 = kb.next();
        
        String Items[] = {item1, item2, item3};
        
        System.out.println("Enter price of the first item ");
        Double price1 = kb.nextDouble();
        
        System.out.println("Enter the price of the second item ");
        Double price2 = kb.nextDouble();
        
        System.out.println("Enter the price of the third item ");
        Double price3 = kb.nextDouble();
        
        Double Prices[] = {price1, price2, price3};

        Double average = (price1 + price2+ price3)/3;
        String avg = average.toString(); 
        
        System.out.println("Items: " + Arrays.toString(Items));
        System.out.println("Prices: " + Arrays.toString(Prices)); 
        System.out.println("The average price of the items is " + "$"+ avg); 
        
    }//end main method
    
}//end class
